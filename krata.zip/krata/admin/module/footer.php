<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0 BETA
        </div>
        <strong>Copyright &copy; 2020 <a href="#">TUGAS PSE</a>.</strong> All rights reserved.
      </footer>