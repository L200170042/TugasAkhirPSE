
<?php
    $conn = mysqli_connect ('localhost', 'root', '','krata');
    //mengambil data dari url
    
    //menghapus data
    $koneksi->query("DELETE FROM karyawan WHERE id_karyawan='$_GET[id]'"); 

	
	echo "<meta http-equiv='refresh' content='1;url=index.php?module=karyawan/karyawan'>";
?>
