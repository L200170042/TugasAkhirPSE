<?php

//koneksi database
$koneksi = new mysqli("localhost","root","","krata");

?>
<section class="content-header">
	<h1>Data KARYAWAN</h1>
</section>

<section class="content">
	<div class="box">
		<div class="box-header">
			<div class="row">

				<!--pencarian menggunakan tanggal 
				
				<div class="col-md-2">
					<input type="text" id="date" class="form-control" name="tanggal-cari" placeholder="masukan tanggal" />
				</div>
				<div class="col-md-1">
					<a class="btn btn-info" href="#">Cari</a>
				</div>
				-->
			</div>		
		</div>
		<div class="box-body">
			<table class="table table-bordered table-striped" id="table1">
				<thead class="thead-dark">
					<tr>
						<th>No</th>
						<th>Nama</th>
						<th>Alamat</th>
						<th>Gaji (per-bulan)</th>
						<th>Jabatan</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $nomor=1; ?>
					<?php $ambil=$koneksi->query("SELECT * FROM karyawan"); ?>	
					<?php while($user = $ambil->fetch_assoc()){?>
					<tr>
						<td><?php echo $nomor?></td>
						<td><?php echo $user['nama_karyawan']; ?></td>
						<td><?php echo $user['alamat_karyawan']; ?></td>
						<td>Rp. <?php echo number_format ($user['gaji']); ?></td>
						<td><?php echo $user['jabatan']; ?></td>
						<td>
							<a href="#" data-toggle="modal" data-target="#myModal<?php echo $user['id_karyawan']; ?>" class="btn btn-success btn-sm rounded-0" type="button" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?module=karyawan/karyawan-delete&id=<?php echo $user['id_karyawan']; ?>"class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
						</td>
					</tr>


					<!-- modal edit -->
					<div class="modal fade" id="myModal<?php echo $user['id_karyawan']; ?>" role="dialog">
						<div class="modal-dialog">
						<!-- modal content -->
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Edit Data Karyawan</h4>
								</div>

								<?php
									$id = $user['id_karyawan']; 
									$ambil2=$koneksi->query("SELECT * FROM karyawan WHERE id_karyawan='$id'");
								
									while ($pecah = mysqli_fetch_array($ambil2)){
								?>

								<form method="post" ectype="multipart/form-data">
									<div class="modal-body">
										<div class="form-group">
											<label class="control-label">Nama</label>
											<input type="hidden" name="id_karyawan" value="<?php echo $pecah['id_karyawan']; ?>">
											<input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama_karyawan']; ?>" required>
										</div>
										<div class="form-group">
											<label class="control-label">Alamat</label>
											<input type="text" name="alamat_karyawan" class="form-control" value="<?php echo $pecah['alamat_karyawan']; ?>" required>
										</div>
										<div class="form-group">
											<label class="control-label">Gaji (per-bulan)</label>
											<input type="text" name="gaji" class="form-control" value="<?php echo $pecah['gaji']; ?>" required>
										</div>
										<div class="form-group">
											<label class="control-label">Jabatan</label>
											<input type="text" name="jabatan" class="form-control" value="<?php echo $pecah['jabatan']; ?>" required>
										</div>
									
									</div>
									
									<!-- footer modal -->
									<div class="modal-footer">
										
										<button type="submit" class="btn btn-success" name="ubah" >Simpan</button>
									</div>
								</form>
								
									<?php } ?>
								
								

							</div>
						</div>
					</div>


					<?php $nomor++; ?>
					<?php } ?>
					<?php
								if (isset($_POST['ubah']))
								{
									$koneksi->query("UPDATE karyawan SET
										nama_karyawan='$_POST[nama]', alamat_karyawan='$_POST[alamat_karyawan]', gaji='$_POST[gaji]', jabatan='$_POST[jabatan]' 
										WHERE id_karyawan= '$_POST[id_karyawan]'");
										

									
									echo "<div class='alert alert-info'>Data Tersimpan</div>";
									//echo "<meta http-equiv='refresh' content='1;url=index.php?module=wonogiri/wonogiri-list'>";
									echo "<script>location='index.php?module=karyawan/karyawan-list';</script>";
								}
					?>
				</tbody>
			</table>

<!-- modal tambah-->
			<button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambah">Tambah Data</button>

			<div id="tambah" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Tambah Karyawan</h4>
						</div>
						<form method="post" enctype="multipart/form-data">
							<div class="modal-body">
								<div class="form-group">
									<label class="control-label">Nama Karyawan</label>
									<input type="text" class="form-control" name="nama_karyawan" required>
								</div>
								<div class="form-group">
									<label class="control-label">Alamat</label>
									<input type="text" class="form-control" name="alamat_karyawan" required>
								</div>
								<div class="form-group">
									<label class="control-label">Gaji (per-bulan)</label>
									<input type="text" class="form-control" name="gaji" required>
								</div>
								<div class="form-group">
									<label class="control-label">Jabatan</label>
									<input type="text" class="form-control" name="jabatan" required>
								</div>
								<!-- <div class="form-group">
									<label class="control-label">Deskripsi</label>
									<textarea class="form-control" name="deskripsi" rows="5" required></textarea>
								</div> -->
							</div>
							<!-- footer modal -->
							<div class="modal-footer">
								<button type="reset" class="btn btn-danger" >Reset</button>
								<button type="submit" class="btn btn-success" name="tambah" >Simpan</button>
							</div>
						</form>
						
						<?php
						if (isset($_POST['tambah']))
						{
							$koneksi->query("INSERT INTO karyawan
								(nama_karyawan,alamat_karyawan,gaji,jabatan)
								VALUES('$_POST[nama_karyawan]','$_POST[alamat_karyawan]','$_POST[gaji]','$_POST[jabatan]')");
							
							echo "<div class='alert alert-info'>Data Tersimpan</div>";
							echo "<meta http-equiv='refresh' content='1;url=index.php?module=karyawan/karyawan-list'>";
							//header("location: ?module=produk/produk-list");
						}
						?>

					</div>
				</div>
			</div>
			
		</div>
	</div>
</section>