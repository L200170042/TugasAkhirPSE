<?php

//koneksi database
$koneksi = new mysqli("localhost","root","","krata");

?>
<section class="content-header">
	<h1>Dashboard <span class="small">Data Accounting</span></h1>
</section>

<section class="content">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-md-6">
				<!-- CHART Beras Pre -->
				<div class="card card-primary">
					<div class="card-body">
						<div class="chart">
							<canvas id="linechart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
          <div class="col-lg-3 col-3">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
                <?php
                  $ambil = $koneksi->query("SELECT SUM(total_pembelian) AS total FROM pembelian");
                  while($data = $ambil->fetch_assoc()){
                ?>
                  <h3><span class="small bg-yellow">Rp.<?php echo number_format ($data['total']);?></span></h3>
                  <?php }?>
                <p>Total Pemasukan</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="?module=pembelian/pembelian-list" class="small-box-footer">More info <i class="fa fa-arrow-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-3">
            <!-- small box -->
            <div class="small-box bg-blue">
              <div class="inner">
              <?php
                  $ambil2 = $koneksi->query("SELECT SUM(gaji) AS total FROM karyawan");
                  while($data = $ambil2->fetch_assoc()){
                ?>
                  <h3><span class="small bg-blue">Rp.<?php echo number_format ($data['total']);?></span></h3>
                  <?php }?>
                <p>Total Pengluaran Gaji</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="?module=karyawan/karyawan-list" class="small-box-footer">More info <i class="fa fa-arrow-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
    
    <div class="box">
        <div class="box-body">
            <div class = "row">
             <!-- tabel pengluaran -->
                <div class="col-md-6">
                    <h3>Tabel Pengluaran Lain</h3>
                    <table class="table table-bordered table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>No</th>
                                <th>Keterangan</th>
                                <th>Jumlah</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $nomor=1; ?>
                            <?php $ambil3=$koneksi->query("SELECT * FROM pengluaran"); ?>	
                            <?php while($user = $ambil3->fetch_assoc()){?>
                            <tr>
                                <td><?php echo $nomor?></td>
                                <td><?php echo $user['keterangan']; ?></td>
                                <td>Rp.<?php echo number_format ($user['Jumlah']); ?></td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#myModal<?php echo $user['id_pengluaran']; ?>" class="btn btn-success btn-sm rounded-0" type="button" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
                                    <a href="index.php?module=accounting/accounting-delete&id=<?php echo $user['id_pengluaran']; ?>"class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>


                            <!-- modal edit -->
                            <div class="modal fade" id="myModal<?php echo $user['id_pengluaran']; ?>" role="dialog">
                                <div class="modal-dialog">
                                <!-- modal content -->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Edit Data Pengluaran Lain</h4>
                                        </div>

                                        <?php
                                            $id = $user['id_pengluaran']; 
                                            $ambil4=$koneksi->query("SELECT * FROM pengluaran WHERE id_pengluaran='$id'");
                                        
                                            while ($pecah = mysqli_fetch_array($ambil4)){
                                        ?>

                                        <form method="post" ectype="multipart/form-data">
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label class="control-label">Keterangan</label>
                                                    <input type="hidden" name="id_pengluaran" value="<?php echo $pecah['id_pengluaran']; ?>">
                                                    <input type="text" name="ket" class="form-control" value="<?php echo $pecah['keterangan']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Jumlah (Rp.)</label>
                                                    <input type="text" name="jml" class="form-control" value="<?php echo $pecah['Jumlah']; ?>" required>
                                                </div>
                                            </div>
                                            
                                            <!-- footer modal -->
                                            <div class="modal-footer">
                                                
                                                <button type="submit" class="btn btn-success" name="ubah" >Simpan</button>
                                            </div>
                                        </form>
                                        
                                            <?php } ?>
                                        
                                        

                                    </div>
                                </div>
                            </div>


                            <?php $nomor++; ?>
                            <?php } ?>
                            <?php
                                        if (isset($_POST['ubah']))
                                        {
                                            $koneksi->query("UPDATE pengluaran SET
                                                keterangan='$_POST[ket]', Jumlah='$_POST[jml]'
                                                WHERE id_pengluaran= '$_POST[id_pengluaran]'");
                                                

                                            
                                            echo "<div class='alert alert-info'>Data Tersimpan</div>";
                                            //echo "<meta http-equiv='refresh' content='1;url=index.php?module=wonogiri/wonogiri-list'>";
                                            echo "<script>location='index.php?module=accounting/accounting-list';</script>";
                                        }
                            ?>
                        </tbody>
                    </table>

                    <!-- modal tambah-->
                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambah">Tambah Data</button>

                    <div id="tambah" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Tambah Pengluaran Lain</h4>
                                </div>
                                <form method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="control-label">Keterangan</label>
                                            <input type="text" class="form-control" name="ket" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Jumlah (Rp.)</label>
                                            <input type="number" class="form-control" name="jml" required>
                                        </div>
                                        
                                    </div>
                                    <!-- footer modal -->
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-danger" >Reset</button>
                                        <button type="submit" class="btn btn-success" name="tambah" >Simpan</button>
                                    </div>
                                </form>
                                
                                <?php
                                if (isset($_POST['tambah']))
                                {
                                    $koneksi->query("INSERT INTO pengluaran
                                        (keterangan,Jumlah)
                                        VALUES('$_POST[ket]','$_POST[jml]')");
                                    
                                    echo "<div class='alert alert-info'>Data Tersimpan</div>";
                                    echo "<meta http-equiv='refresh' content='1;url=index.php?module=accounting/accounting-list'>";
                                    //header("location: ?module=produk/produk-list");
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>


            <!-- tabel Keuangan -->
                <div class="col-md-6">
                    <h3>Tabel Keuangan</h3>
                    <table class="table table-bordered table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Pemasukan</th>
                                <th>Pengluaran</th>
                                <th>Total Bersih</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>

                            <!-- masih Salah -->
                                <?php
                                $ambil5 = $koneksi->query("SELECT SUM(pembelian.total_pembelian) AS total3 
                                                        FROM pembelian");
                                $data = mysqli_fetch_array($ambil5);
                                ?>
                                <td>Rp.<?php echo number_format ($data['total3']);?></td>

                                <?php
                                $ambil6 = $koneksi->query("SELECT SUM(karyawan.gaji) AS total2 
                                                        FROM karyawan");
                                $ambil7 = $koneksi->query("SELECT SUM(pengluaran.Jumlah) AS total 
                                FROM pengluaran");
                                $data0 = mysqli_fetch_array($ambil6);
                                $data1 = mysqli_fetch_array($ambil7);
                                ?>
                                <td>Rp.<?php echo number_format ($data1['total']+$data0['total2']); ?></td>
                                <td>
                                    Rp.<?php echo number_format ($data['total3']-($data1['total']+$data0['total2'])); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
