
<?php
    $conn = mysqli_connect ('localhost', 'root', '','krata');
    //mengambil data dari url
    
    //menghapus data
    $koneksi->query("DELETE FROM pengluaran WHERE id_pengluaran='$_GET[id]'"); 

	
	echo "<meta http-equiv='refresh' content='1;url=index.php?module=accounting/accounting-list'>";
?>
