<?php

//koneksi database
$koneksi = new mysqli("localhost","root","","krata");

?>
<section class="content-header">
	<h1>Data DOKUMEN</h1>
</section>

<section class="content">
	<div class="box">
		<div class="box-header">
			<div class="row">
			</div>		
		</div>
		<div class="box-body">
			<table class="table table-bordered table-striped" id="table1">
				<thead class="thead-dark">
					<tr>
						<th>No</th>
						<th>Nomer Dokumen</th>
						<th>Keterangan</th>
						<th>Kategori</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $nomor=1; ?>
					<?php $ambil=$koneksi->query("SELECT * FROM dokumen"); ?>	
					<?php while($user = $ambil->fetch_assoc()){?>
					<tr>
						<td><?php echo $nomor?></td>
						<td><?php echo $user['no_dokumen']; ?></td>
						<td><?php echo $user['keterangan']; ?></td>
						<td><?php echo $user['kategori_dokumen']; ?></td>
						<td>
							<a href="#" data-toggle="modal" data-target="#myModal<?php echo $user['id_dokumen']; ?>" class="btn btn-success btn-sm rounded-0" type="button" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?module=dokumen/dokumen-delete&id=<?php echo $user['id_dokumen']; ?>"class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
						</td>
					</tr>


					<!-- modal edit -->
					<div class="modal fade" id="myModal<?php echo $user['id_dokumen']; ?>" role="dialog">
						<div class="modal-dialog">
						<!-- modal content -->
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Edit Data Dokumen</h4>
								</div>

								<?php
									$id = $user['id_dokumen']; 
									$ambil2=$koneksi->query("SELECT * FROM dokumen WHERE id_dokumen='$id'");
								
									while ($pecah = mysqli_fetch_array($ambil2)){
								?>

								<form method="post" ectype="multipart/form-data">
									<div class="modal-body">
										<div class="form-group">
											<label class="control-label">Nomer Dokumen (SM/SK)</label>
											<input type="hidden" name="id_dokumen" value="<?php echo $pecah['id_dokumen']; ?>">
											<input type="text" name="nodok" class="form-control" value="<?php echo $pecah['no_dokumen']; ?>" required>
										</div>
										<div class="form-group">
											<label class="control-label">Keterangan</label>
											<input type="text" name="keterangan" class="form-control" value="<?php echo $pecah['keterangan']; ?>" required>
										</div>
										<div class="form-group">
											<label class="control-label">Kategori : </label><br>
											<input type="radio" name="kategori" value="Surat Masuk" <?php if($pecah['kategori_dokumen']=='Surat Masuk') echo 'checked'?>>  Surat Masuk   
      										<input type="radio" name="kategori" value="Surat Keluar" <?php if($pecah['kategori_dokumen']=='Surat Keluar') echo 'checked'?>>  Surat Keluar   
										</div>
									</div>
									
									<!-- footer modal -->
									<div class="modal-footer">
										<button type="submit" class="btn btn-success" name="ubah" >Simpan</button>
									</div>
								</form>
								
									<?php } ?>
								
								

							</div>
						</div>
					</div>


					<?php $nomor++; ?>
					<?php } ?>
					<?php
								if (isset($_POST['ubah']))
								{
									$koneksi->query("UPDATE dokumen SET
										no_dokumen='$_POST[nodok]', keterangan='$_POST[keterangan]', kategori_dokumen='$_POST[kategori]' 
										WHERE id_dokumen= '$_POST[id_dokumen]'");
										

									
									echo "<div class='alert alert-info'>Data Tersimpan</div>";
									//echo "<meta http-equiv='refresh' content='1;url=index.php?module=wonogiri/wonogiri-list'>";
									echo "<script>location='index.php?module=dokumen/dokumen-list';</script>";
								}
					?>
				</tbody>
			</table>
			
			<!-- modal tambah-->
			<button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambah">Tambah Data</button>

			<div id="tambah" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Tambah Dokumen</h4>
						</div>
						<form method="post" enctype="multipart/form-data">
							<div class="modal-body">
								<div class="form-group">
									<label class="control-label">Nomer Dokumen (SM/Sk)</label>
									<input type="text" class="form-control" name="nodok" required>
								</div>
								<div class="form-group">
									<label class="control-label">Keterangan</label>
									<input type="text" class="form-control" name="keterangan" required>
								</div>
								<div class="form-group">
								<label class="control-label">Kategori : </label><br>
								<input type="radio" name="kategori" value="Surat Masuk" >  Surat Masuk   
      							<input type="radio" name="kategori" value="Surat Keluar" >  Surat Keluar   
								</div>
							</div>
							<!-- footer modal -->
							<div class="modal-footer">
								<button type="reset" class="btn btn-danger" >Reset</button>
								<button type="submit" class="btn btn-success" name="tambah" >Simpan</button>
							</div>
						</form>
						
						<?php
						if (isset($_POST['tambah']))
						{
							
							$koneksi->query("INSERT INTO dokumen
								(no_dokumen,keterangan,kategori_dokumen)
								VALUES('$_POST[nodok]','$_POST[keterangan]','$_POST[kategori]')");
							
							echo "<div class='alert alert-info'>Data Tersimpan</div>";
							echo "<meta http-equiv='refresh' content='1;url=index.php?module=dokumen/dokumen-list'>";
							//header("location: ?module=produk/produk-list");
						}
						?>

					</div>
				</div>
			</div>
			
		</div>
	</div>
</section>